﻿#nullable disable
using APP.Models;
using CORE.Services;
using Microsoft.AspNetCore.Mvc;

namespace MVC.Controllers
{
    public class CategoriesController : Controller
    {
        private readonly IService<CategoryRequest, CategoryResponse> _categoryService;

        public CategoriesController(IService<CategoryRequest, CategoryResponse> categoryService)
        {
            _categoryService = categoryService;
        }

        private void SetTempData(string message, string key = "Message")
        {
            TempData[key] = message;
        }

        public IActionResult Index()
        {
            var list = _categoryService.List();
            return View(list);
        }

        public IActionResult Details(int id)
        {
            var item = _categoryService.Single(id);
            return View(item);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Create(CategoryRequest category)
        {
            if (ModelState.IsValid)
            {
                var response = _categoryService.Add(category);
                if (response.IsSuccessful)
                {
                    SetTempData(response.Message);
                    return RedirectToAction(nameof(Details), new { id = response.Id });
                }
                ModelState.AddModelError("", response.Message);
            }
            return View(category);
        }

        public IActionResult Edit(int id)
        {
            var item = _categoryService.Edit(id);
            return View(item);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Edit(CategoryRequest category)
        {
            if (ModelState.IsValid)
            {
                var response = _categoryService.Update(category);
                if (response.IsSuccessful)
                {
                    SetTempData(response.Message);
                    return RedirectToAction(nameof(Details), new { id = response.Id });
                }
                ModelState.AddModelError("", response.Message);
            }
            return View(category);
        }

        public IActionResult Delete(int id)
        {
            var item = _categoryService.Single(id);
            return View(item);
        }

        [HttpPost, ValidateAntiForgeryToken, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            var response = _categoryService.Remove(id);
            SetTempData(response.Message);
            return RedirectToAction(nameof(Index));
        }
    }
}
