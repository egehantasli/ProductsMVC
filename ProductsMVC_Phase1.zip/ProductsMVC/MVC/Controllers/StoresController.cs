﻿#nullable disable
using APP.Models;
using CORE.Services;
using Microsoft.AspNetCore.Mvc;

namespace MVC.Controllers
{
    public class StoresController : Controller
    {
        private readonly IService<StoreRequest, StoreResponse> _storeService;

        public StoresController(IService<StoreRequest, StoreResponse> storeService)
        {
            _storeService = storeService;
        }

        private void SetTempData(string message, string key = "Message")
        {
            TempData[key] = message;
        }

        public IActionResult Index()
        {
            var list = _storeService.List();
            return View(list);
        }

        public IActionResult Details(int id)
        {
            var item = _storeService.Single(id);
            return View(item);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Create(StoreRequest store)
        {
            if (ModelState.IsValid)
            {
                var response = _storeService.Add(store);
                if (response.IsSuccessful)
                {
                    SetTempData(response.Message);
                    return RedirectToAction(nameof(Details), new { id = response.Id });
                }
                ModelState.AddModelError("", response.Message);
            }
            return View(store);
        }

        public IActionResult Edit(int id)
        {
            var item = _storeService.Edit(id);
            return View(item);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Edit(StoreRequest store)
        {
            if (ModelState.IsValid)
            {
                var response = _storeService.Update(store);
                if (response.IsSuccessful)
                {
                    SetTempData(response.Message);
                    return RedirectToAction(nameof(Details), new { id = response.Id });
                }
                ModelState.AddModelError("", response.Message);
            }
            return View(store);
        }

        public IActionResult Delete(int id)
        {
            var item = _storeService.Single(id);
            return View(item);
        }

        [HttpPost, ValidateAntiForgeryToken, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            var response = _storeService.Remove(id);
            SetTempData(response.Message);
            return RedirectToAction(nameof(Index));
        }
    }
}
