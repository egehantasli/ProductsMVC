﻿#nullable disable
using APP.Models;
using CORE.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace MVC.Controllers
{
    public class ProductsController : Controller
    {
        private readonly IService<ProductRequest, ProductResponse> _productService;
        private readonly IService<CategoryRequest, CategoryResponse> _categoryService;
        private readonly IService<StoreRequest, StoreResponse> _storeService;

        public ProductsController(IService<ProductRequest, ProductResponse> productService,
            IService<CategoryRequest, CategoryResponse> categoryService,
            IService<StoreRequest, StoreResponse> storeService)
        {
            _productService = productService;
            _categoryService = categoryService;
            _storeService = storeService;
        }

        private void SetViewData()
        {
            ViewData["CategoryId"] = new SelectList(_categoryService.List(), "Id", "Title");
            ViewBag.StoreIds = new MultiSelectList(_storeService.List(), "Id", "Name");
        }

        private void SetTempData(string message, string key = "Message")
        {
            TempData[key] = message;
        }

        public IActionResult Index()
        {
            var list = _productService.List();
            return View(list);
        }

        public IActionResult Details(int id)
        {
            var item = _productService.Single(id);
            return View(item);
        }

        public IActionResult Create()
        {
            SetViewData();
            return View();
        }

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Create(ProductRequest product)
        {
            if (ModelState.IsValid)
            {
                var response = _productService.Add(product);
                if (response.IsSuccessful)
                {
                    SetTempData(response.Message);
                    return RedirectToAction(nameof(Details), new { id = response.Id });
                }
                ModelState.AddModelError("", response.Message);
            }
            SetViewData();
            return View(product);
        }

        public IActionResult Edit(int id)
        {
            var item = _productService.Edit(id);
            SetViewData();
            return View(item);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Edit(ProductRequest product)
        {
            if (ModelState.IsValid)
            {
                var response = _productService.Update(product);
                if (response.IsSuccessful)
                {
                    SetTempData(response.Message);
                    return RedirectToAction(nameof(Details), new { id = response.Id });
                }
                ModelState.AddModelError("", response.Message);
            }
            SetViewData();
            return View(product);
        }

        public IActionResult Delete(int id)
        {
            var item = _productService.Single(id);
            return View(item);
        }

        [HttpPost, ValidateAntiForgeryToken, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            var response = _productService.Remove(id);
            SetTempData(response.Message);
            return RedirectToAction(nameof(Index));
        }
    }
}
