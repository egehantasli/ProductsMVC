﻿using APP.Domain;
using APP.Models;
using CORE.Models;
using CORE.Services;
using Microsoft.EntityFrameworkCore;

namespace APP.Services
{
    public class StoreService : DbService<Store>,
        IService<StoreRequest, StoreResponse>
    {
        public StoreService(DbContext db) : base(db)
        {
        }

        protected override IQueryable<Store> DbQuery()
        {
            return base.DbQuery()
                .Include(s => s.ProductStores)
                .ThenInclude(ps => ps.Product)
                .OrderBy(s => s.Name);
        }

        public IQueryable<StoreResponse> Query()
        {
            return DbQuery()
                .Select(s => new StoreResponse
                {
                    Id = s.Id,
                    Name = s.Name,
                    IsVirtual = s.IsVirtual,
                    IsVirtualR = s.IsVirtual ? "Yes" : "No",
                    ProductNamesR = string.Join(", ", s.ProductStores
                        .OrderBy(ps => ps.Product.Name)
                        .Select(ps => ps.Product.Name)),
                    ProductCountR = s.ProductStores.Count
                });
        }

        public StoreRequest Edit(int id)
        {
            var storeEntity = DbSingle(id);
            if (storeEntity is null)
                return null;
            return new StoreRequest
            {
                Id = storeEntity.Id,
                Name = storeEntity.Name,
                IsVirtual = storeEntity.IsVirtual
            };
        }

        public CommandResponse Add(StoreRequest request)
        {
            if (DbQuery()
                .Any(s => s.Name == request.Name.Trim()))
                return Error("Store with the same name exists!");
            var storeEntity = new Store
            {
                Name = request.Name.Trim(),
                IsVirtual = request.IsVirtual
            };
            DbAdd(storeEntity);
            return Success(storeEntity.Id, "Store created successfully.");
        }

        public CommandResponse Update(StoreRequest request)
        {
            if (DbQuery()
                .Any(s => s.Id != request.Id &&
                    s.Name == request.Name.Trim()))
                return Error("Store with the same name exists!");
            var storeEntity = DbSingle(request.Id);
            if (storeEntity is null)
                return Error("Store not found!");
            storeEntity.Name = request.Name.Trim();
            storeEntity.IsVirtual = request.IsVirtual;
            DbUpdate(storeEntity);
            return Success(storeEntity.Id, "Store updated successfully.");
        }

        public CommandResponse Remove(int id)
        {
            var storeEntity = DbSingle(id);
            if (storeEntity is null)
                return Error("Store not found!");
            if (storeEntity.ProductStores.Any())
                return Error("Store has relational products!");
            DbRemove(storeEntity);
            return Success(storeEntity.Id, "Store deleted successfully.");
        }
    }
}
