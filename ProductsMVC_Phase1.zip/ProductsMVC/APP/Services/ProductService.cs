﻿using APP.Domain;
using APP.Models;
using CORE.Models;
using CORE.Services;
using Microsoft.EntityFrameworkCore;

namespace APP.Services
{
    public class ProductService : DbService<Product>,
        IService<ProductRequest, ProductResponse>
    {
        public ProductService(DbContext db) : base(db)
        {
        }

        protected override IQueryable<Product> DbQuery()
        {
            return base.DbQuery()
                .Include(p => p.Category)
                .Include(p => p.ProductStores)
                .ThenInclude(ps => ps.Store)
                .OrderBy(p => p.Category.Title)
                .ThenBy(p => p.Name);
        }

        public IQueryable<ProductResponse> Query()
        {
            return DbQuery().Select(p => new ProductResponse
            {
                Id = p.Id,
                Name = p.Name,
                UnitPrice = p.UnitPrice,
                StockAmount = p.StockAmount,
                ExpirationDate = p.ExpirationDate,
                CategoryId = p.CategoryId,
                CategoryTitleR = p.Category.Title,
                CategoryR = new CategoryResponse
                {
                    Id = p.Category.Id,
                    Title = p.Category.Title,
                    Description = p.Category.Description
                },
                StoreNamesR = string.Join("<br>", p.ProductStores
                    .OrderBy(ps => ps.Store.Name)
                    .Select(ps => ps.Store.Name)),
                StoresR = p.ProductStores.OrderBy(ps => ps.Store.Name)
                    .Select(ps => new StoreResponse
                {
                    Id = ps.Store.Id,
                    Name = ps.Store.Name,
                    IsVirtual = ps.Store.IsVirtual
                }).ToList(),
                UnitPriceR = p.UnitPrice.ToString("C2"),
                StockAmountR = p.StockAmount.HasValue ?
                    p.StockAmount.Value.ToString() :
                    string.Empty,
                ExpirationDateR = p.ExpirationDate.HasValue ?
                    p.ExpirationDate.Value.ToShortDateString() :
                    string.Empty
            });
        }

        public ProductRequest Edit(int id)
        {
            var productEntity = DbSingle(id);
            if (productEntity is null)
                return null;
            return new ProductRequest
            {
                Id = productEntity.Id,
                Name = productEntity.Name,
                UnitPrice = productEntity.UnitPrice,
                StockAmount = productEntity.StockAmount,
                ExpirationDate = productEntity.ExpirationDate,
                CategoryId = productEntity.CategoryId,
                StoreIds = productEntity.StoreIds
            };
        }

        public CommandResponse Add(ProductRequest request)
        {
            if (DbQuery().Any(p =>
                p.Name == request.Name.Trim()
            ))
                return Error("Product with the same name exists!");
            var productEntity = new Product
            {
                Name = request.Name.Trim(),
                UnitPrice = request.UnitPrice ?? 0,
                StockAmount = request.StockAmount,
                ExpirationDate = request.ExpirationDate,
                CategoryId = request.CategoryId ?? 0,
                StoreIds = request.StoreIds
            };
            DbAdd(productEntity);
            return Success(productEntity.Id, "Product created successfully.");
        }

        public CommandResponse Update(ProductRequest request)
        {
            if (DbQuery().Any(p => p.Id != request.Id
                && p.Name == request.Name.Trim()))
                return Error("Product with the same name exists!");
            var productEntity = DbSingle(request.Id);
            if (productEntity is null)
                return Error("Product not found!");
            if (request.StoreIds is not null)
                DbRemove(productEntity.ProductStores);
            productEntity.Name = request.Name.Trim();
            if (request.UnitPrice.HasValue)
                productEntity.UnitPrice = request.UnitPrice.Value;
            productEntity.StockAmount = request.StockAmount;
            productEntity.ExpirationDate = request.ExpirationDate;
            if (request.CategoryId.HasValue)
                productEntity.CategoryId = request.CategoryId.Value;
            if (request.StoreIds is not null)
                productEntity.StoreIds = request.StoreIds;
            DbUpdate(productEntity);
            return Success(productEntity.Id, "Product updated successfully.");
        }

        public CommandResponse Remove(int id)
        {
            var productEntity = DbSingle(id);
            if (productEntity is null)
                return Error("Product not found!");
            DbRemove(productEntity.ProductStores);
            DbRemove(productEntity);
            return Success(productEntity.Id, "Product deleted successfully.");
        }
    }
}
