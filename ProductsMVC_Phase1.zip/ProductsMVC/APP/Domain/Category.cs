﻿using CORE.Domain;
using System.ComponentModel.DataAnnotations;

namespace APP.Domain
{
    public class Category : Record
    {
        [Required, StringLength(100)]
        public string Title { get; set; }

        public string Description { get; set; }

        public List<Product> Products { get; set; } = new();
    }
}
