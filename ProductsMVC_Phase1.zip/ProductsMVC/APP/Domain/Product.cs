﻿using CORE.Domain;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace APP.Domain
{
    public class Product : Record
    {
        [Required, StringLength(150)]
        public string Name { get; set; }

        public decimal UnitPrice { get; set; }

        public int? StockAmount { get; set; }

        public DateTime? ExpirationDate { get; set; }

        public int CategoryId { get; set; }

        public Category Category { get; set; }

        public List<ProductStore> ProductStores { get; set; } = new();

        [NotMapped]
        public List<int> StoreIds
        {
            get => ProductStores.Select(productStoreEntity
                => productStoreEntity.StoreId).ToList();
            set => ProductStores = value.Select(storeIdValue => new ProductStore
            {
                StoreId = storeIdValue
            }).ToList();
        }
    }
}
