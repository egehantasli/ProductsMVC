﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using System.Globalization;

namespace APP.Domain
{
    public class DbFactory : IDesignTimeDbContextFactory<Db>
    {
        const string CONNECTIONSTRING = "data source=DB.db";

        public Db CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<Db>();
            optionsBuilder.UseSqlite(CONNECTIONSTRING);
            return new Db(optionsBuilder.Options);
        }

        public void SeedDb()
        {
            var db = CreateDbContext(null);

            var productStores = db.ProductStores.ToList();
            db.ProductStores.RemoveRange(productStores);
            var products = db.Products.ToList();
            db.Products.RemoveRange(products);
            var stores = db.Stores.ToList();
            db.Stores.RemoveRange(stores);
            var categories = db.Categories.ToList();
            db.Categories.RemoveRange(categories);

            db.Database.ExecuteSqlRaw("UPDATE SQLITE_SEQUENCE " +
                "SET SEQ=0 WHERE NAME='ProductStores'");
            db.Database.ExecuteSqlRaw("UPDATE SQLITE_SEQUENCE " +
                "SET SEQ=0 WHERE NAME='Products'");
            db.Database.ExecuteSqlRaw("UPDATE SQLITE_SEQUENCE " +
                "SET SEQ=0 WHERE NAME='Stores'");
            db.Database.ExecuteSqlRaw("UPDATE SQLITE_SEQUENCE " +
                "SET SEQ=0 WHERE NAME='Categories'");

            db.Stores.Add(new Store { Name = "Amazon", IsVirtual = true });
            db.Stores.Add(new Store { Name = "Hepsiburada", IsVirtual = true });
            db.Stores.Add(new Store { Name = "MediaMarkt Ankara", IsVirtual = false });
            db.Stores.Add(new Store { Name = "Migros Bilkent", IsVirtual = false });
            db.SaveChanges();

            db.Categories.Add(new Category
            {
                Title = "Computer",
                Description = "Laptops, desktops and computer accessories",
                Products = new List<Product>
                {
                    new Product
                    {
                        Name = "Lenovo ThinkPad E14",
                        UnitPrice = 32999.99m,
                        StockAmount = 15,
                        ProductStores = new List<ProductStore>
                        {
                            new ProductStore { StoreId = db.Stores.Single(
                                s => s.Name == "Amazon").Id },
                            new ProductStore { StoreId = db.Stores.Single(
                                s => s.Name == "MediaMarkt Ankara").Id }
                        }
                    },
                    new Product
                    {
                        Name = "Logitech MX Master 3S Mouse",
                        UnitPrice = 3499.90m,
                        StockAmount = 40,
                        ProductStores = new List<ProductStore>
                        {
                            new ProductStore { StoreId = db.Stores.Single(
                                s => s.Name == "Hepsiburada").Id },
                            new ProductStore { StoreId = db.Stores.Single(
                                s => s.Name == "MediaMarkt Ankara").Id }
                        }
                    }
                }
            });
            db.Categories.Add(new Category
            {
                Title = "Phone",
                Description = "Smartphones",
                Products = new List<Product>
                {
                    new Product
                    {
                        Name = "Samsung Galaxy S24",
                        UnitPrice = 45999m,
                        StockAmount = 8,
                        ProductStores = new List<ProductStore>
                        {
                            new ProductStore { StoreId = db.Stores.Single(
                                s => s.Name == "Amazon").Id },
                            new ProductStore { StoreId = db.Stores.Single(
                                s => s.Name == "Hepsiburada").Id }
                        }
                    }
                }
            });
            db.Categories.Add(new Category
            {
                Title = "Food",
                Description = "Food and beverages",
                Products = new List<Product>
                {
                    new Product
                    {
                        Name = "Organic Milk 1L",
                        UnitPrice = 54.95m,
                        StockAmount = 120,
                        ExpirationDate = new DateTime(2026, 12, 31),
                        ProductStores = new List<ProductStore>
                        {
                            new ProductStore { StoreId = db.Stores.Single(
                                s => s.Name == "Migros Bilkent").Id }
                        }
                    },
                    new Product
                    {
                        Name = "Dark Chocolate 80g",
                        UnitPrice = 89.90m,
                        ExpirationDate = DateTime.Parse("06/30/2027",
                            new CultureInfo("en-US")),
                        ProductStores = new List<ProductStore>
                        {
                            new ProductStore { StoreId = db.Stores.Single(
                                s => s.Name == "Migros Bilkent").Id },
                            new ProductStore { StoreId = db.Stores.Single(
                                s => s.Name == "Hepsiburada").Id }
                        }
                    }
                }
            });
            db.Categories.Add(new Category { Title = "Home Theater System" });
            db.SaveChanges();
        }
    }
}
