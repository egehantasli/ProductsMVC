﻿using CORE.Domain;
using System.ComponentModel.DataAnnotations;

namespace APP.Models
{
    public class CategoryRequest : Record
    {
        [Required, StringLength(100)]
        public string Title { get; set; }

        public string Description { get; set; }
    }
}
